<?php      
   
    $servername='localhost';
    $username='root';
    $password='';

    $dbname = "fitjobs";

    $conn=mysqli_connect($servername,$username,$password,"$dbname");
      if(!$conn){
          die('Could not Connect MySql Server:' .mysql_error() );
        }



    $username = $_POST['user'];  
    $password = $_POST['pass'];  
      
        //to prevent from mysqli injection  
        $username = stripcslashes($username);  
        $password = stripcslashes($password);  
        $username = mysqli_real_escape_string($conn, $username);  
        $password = mysqli_real_escape_string($conn, $password);  
      
        $sql = "select *from admin where username = '$username' and password = '$password'";  
        $result = mysqli_query($conn, $sql);  
        $row = mysqli_fetch_array($result,MYSQLI_ASSOC);  
        $count = mysqli_num_rows($result);  
          
        if($count == 1){  
          header("Location:http://localhost/fitjobs/admin/adminpanel.php");
        }  
        else{  
			 
            echo "<h1> Login failed. Invalid username or password.</h1>"; 
			header("Location:http://localhost/fitjobs/admin/alogin.html");
        }     
?>  