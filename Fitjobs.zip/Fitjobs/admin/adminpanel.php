<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
<style type="text/css">
body table tbody tr td {
    font-family: Lucida Grande, Lucida Sans Unicode, Lucida Sans, DejaVu Sans, Verdana, sans-serif;
}
</style>
</head>

<body>
	
<h1><em>Admin Panel&nbsp;</em></h1>
<table width="1185" height="219" border="1">
  <tbody>
    <tr>
      <td width="292">&nbsp;</td>
      <td height="109" colspan="2">  welcome Admin</td>
      <td width="281">&nbsp;</td>
    </tr>
    <tr>
      <td colspan="2">Registered Companies</td>
      <td width="287" height="50"><a href="company_view.php" >View </a></td>
      <td><a href="company_delete.php">Delete</a></td>
    </tr>
    <tr>
      <td colspan="2">Registered Users</td>
      <td height="50.8"> <a href="user_view.php">View</a></td>
      <td><a href="user_delete.php">Delete</a></td>
    </tr>
  </tbody>
</table>

</body>
</html>