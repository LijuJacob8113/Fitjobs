<?php
include_once 'cdb.php';
if(isset($_POST['submit']))
{    
     $companyname = $_POST['companyname'];
     $email = $_POST['email'];
	  $phoneno = $_POST['phoneno'];
	  $city = $_POST['city'];
	  $state = $_POST['state'];
	  $country = $_POST['country'];
	$companyaddress = $_POST['companyaddress'];
	  $companywebsite = $_POST['companywebsite'];
	  $image = $_POST['image'];
	$companydescription = $_POST['companydescription'];
	  $username = $_POST['username'];
     $password = $_POST['password'];
	  $confirmpassword = $_POST['confirmpassword'];
     $sql = "INSERT INTO company (companyname,email,phoneno,city,state,country,companyaddress,companywebsite,image,companydescription,username,password,confirmpassword)
     VALUES ('$companyname','$email','$phoneno','$city','$state','$country','$companyaddress','$companywebsite','$image','$companydescription','$username','$password','$confirmpassword')";
	
	
     if (mysqli_query($conn, $sql)) {
        echo "Registration is successfull !";
     } else {
        echo "Error: " . $sql . ":-" . mysqli_error($conn);
     }
     mysqli_close($conn);
}
?>