<!doctype html>
<html>
<head>
<meta charset="utf-8">
	<title>Company registration</title>
	<style>
form{
	width: 50%;
	alignment-baseline: center;
	background-color: cornsilk;
	align-content: center;
	margin-left: 400PX;
}

label{
	
	display: inline-block;
	float: left;
	clear: left;
	width: 90px;
	margin: 5px;
	text-align: left;
}
		input[type="text"]{
			width: 250px;
			margin: 5px 0px;
			}
		legend{ width: 70px;
			padding: 2px;
			margin-left: calc(50% - 35px - 8px);
			font-display: optional;
			justify-content: center;
		}
		
	

		</style>
</head>

<body>


<h1>REGISTER NOW</h1>
<p>&nbsp;</p>


	                            <form method="post" action="cinsert.php" class="login">        
<legend > <h3>SIGNUP</h3></legend>

    <p>
    <label for="textfield" class="label">Company Name:</label>
    <input name="companyname" type="text" id="companyname">
  <br><br>
    <label for="email" class="label">Email:</label>
    <input type="email" name="email" id="email">
  <br><br>
    <label for="tel" class="txtfield label">Phone No:</label>
    <input type="tel" name="phoneno" id="phoneno">
    <br><br>
	  <label for="textfield2" class="label">City:</label>
      <input type="text" name="city" id="city">
	<br><br>
    <label for="textfield3" class="label">State:</label>
    <input type="text" name="state" id="state">
  <br><br>
    <label for="textfield4" class="label">Country:</label>
    <input type="text" name="country" id="country">
  <br><br>
    <label for="textfield5" class="label">Company Address:</label>
    <input type="text" name="companyaddress" id="companyaddress">
	 <br><br>
	 
  
	 

     <label for="url">Company Website:</label>
     <input type="url" name="companywebsite" id="companywebsite">
     <br><br>
<label for="fileField">Image:</label>
<input type="file" name="image" id="image">
		<br><br>
		
		<label for="textarea">Company Description:</label>
        <textarea name="companydescription" id="companydescription" rows="8" col="250">
		</textarea>
        <br><br>
<label for="textfield7">Username:</label>
<input type="text" name="username" id="username">
	<br>
<label for="password">Password:</label>
<input type="password" name="password" id="password"><br>
	
	<label for="password2">Confirm Password:</label><br>
	
<input type="password" name="confirmpassword" id="confirmpassword">
	
	<br><br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	
	
	<input type="submit" name="submit" id="submit" value="SIGNUP">
	
	
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<input type="reset" name="reset" id="reset" value="RESET">
	</form>
	</body>  
</html>