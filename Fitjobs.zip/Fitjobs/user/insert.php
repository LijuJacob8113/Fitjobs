<?php
include_once 'db.php';
if(isset($_POST['submit']))
{    
     $name = $_POST['name'];
     $email = $_POST['email'];
	  $contactno = $_POST['contactno'];
	  $city = $_POST['city'];
	  $state = $_POST['state'];
	  $country = $_POST['country'];
	$address = $_POST['address'];
	  $gender = $_POST['gender'];
	  $workstatus = $_POST['workstatus'];
	  $dob = $_POST['dob'];
	  $resume = $_POST['resume'];
	  $username = $_POST['username'];
     $password = $_POST['password'];
	  $confirmpassword = $_POST['confirmpassword'];
     $sql = "INSERT INTO user (name,email,contactno,city,state,country,address,gender,workstatus,dob,resume,username,password,confirmpassword)
     VALUES ('$name','$email','$contactno','$city','$state','$country','$address','$gender','$workstatus','$dob','$resume','$username','$password','$confirmpassword')";
	
	
     if (mysqli_query($conn, $sql)) {
        echo "Registration is successfull !";
     } else {
        echo "Error: " . $sql . ":-" . mysqli_error($conn);
     }
     mysqli_close($conn);
}
?>