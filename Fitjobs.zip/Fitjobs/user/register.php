<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
	<style>
form{
	width: 50%;
	alignment-baseline: center;
	background-color: cornsilk;
	align-content: center;
	margin-left: 400PX;
}

label{
	
	display: inline-block;
	float: left;
	clear: left;
	width: 90px;
	margin: 5px;
	text-align: left;
}
		input[type="text"]{
			width: 250px;
			margin: 5px 0px;
			}
		legend{ width: 70px;
			padding: 2px;
			margin-left: calc(50% - 35px - 8px);
			font-display: optional;
			justify-content: center;
		}
		
	

		</style>
</head>

<body>


<blockquote>
  <h1><em><strong>REGISTER NOW</strong></em></h1>
</blockquote>
<p>&nbsp;</p>


	                            <form method="post" action="insert.php" class="login">        
<legend > <h3>SIGNUP</h3></legend>

    <label for="textfield" class="label">Name:</label>
    <input name="name" type="text" id="name">
  <br><br>
    <label for="email" class="label">Email:</label>
    <input type="email" name="email" id="email">
  <br><br>
    <label for="tel" class="txtfield label">Contact No:</label>
    <input type="tel" name="contactno" id="contactno">
    <br><br>
	  <label for="textfield2" class="label">City:</label>
      <input type="text" name="city" id="city">
	<br><br>
    <label for="textfield3" class="label">State:</label>
    <input type="text" name="state" id="state">
  <br><br>
    <label for="textfield4" class="label">Country:</label>
    <input type="text" name="country" id="country">
  <br><br>
   
    <label for="textarea" class="label">Address:</label>
    <textarea name="address" id="address"></textarea>

	 <br><br>
	 
<label>Gender:</label>
<input  type="radio" name="gender" id="gender" value="male">Male
	<input  type="radio" name="gender" id="gender" value="female">Female
<input  type="radio" name="gender" id="gender" value="Transgender">Trans
</body>  
	 
  <br><br>
  <label for="select" class="label">Work Status:</label>
  <select name="workstatus" id="workstatus">
	  <option>Fresher</option>
	  <option>Unemployed</option>
	  <option>Employed</option>
  </select>
	<br><br>
<label for="date" class="label">DOB:</label>
  <input name="dob" type="date" id="dob">
 
 <br><br>
<label for="fileField">Resume:</label>
<input type="file" name="resume" id="resume">
		<br><br><br><br>
<label for="textfield7">Username:</label>
<input type="text" name="username" id="username">
	<br>
<label for="password">Password:</label>
<input type="password" name="password" id="password"><br>
	
	<label for="password2">Confirm Password:</label><br>
	
<input type="password" name="confirmpassword" id="confirmpassword">
	
	<br><br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	
	
	<input type="submit" name="submit" id="submit" value="SIGNUP">
	
	
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<input type="reset" name="reset" id="reset" value="RESET">
	</form>
	
</html>